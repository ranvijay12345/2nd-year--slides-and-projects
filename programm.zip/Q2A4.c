#include<stdio.h>
float power(int ,int);
int main()
{
    int x,n;
    x = 2;
    n= 8;
  printf("Result of %d^%d is %f: ",x,n,power(x,n));
return 0;
}

float power(int x,int n)
{

    if(n ==0)
        return 1;
    if(n ==1)
        return x;
    if(x == 0)
        return 0;
    if(n%2 == 0)
        return (power(x,n/2) *power(x,n/2));
    else
        return (x *power(x,n/2) *power(x,n/2));
}
