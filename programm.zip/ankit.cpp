#include <bits/stdc++.h>
using namespace std;
long double maxi(long double a,long double b)
{
	if(a>b)
	return a;
	else
	return b;
}
long double* shift(long double len[],int ind,int n)
{
	int i;
	for(i=ind;i<n-1;i++)
	{
		len[i]=len[i+1];
	}
	len[n-1]=0;
	return len;
}
long double tonytime(long double len[],long double time[],int n)
{
   // if(time[n]>0)
    //return time[n];
    int i,j,k;
    long double q=0;
	if(n==0)
	return 0;
	else
	{
		q=0;
   for(j=0;j<n;j++)
   { 
     for()
		for(i=j;i<n;i++)
		{
			if(i>0&&i<n-1)
			q=maxi(q,len[i]+len[i-1]/2+len[i+1]/2+tonytime(shift(len,i,n),time,n-1));
			else
			{
				if(i==0)
				q=maxi(q,len[i]+len[i+1]/2+tonytime(shift(len,i,n),time,n-1));
				if(i==n-1)
				q=maxi(q,len[i]+len[i-1]/2+tonytime(shift(len,i,n),time,n-1));
			}
	   }
  }
}
	return q;
}
int main()
{
	int n,i;
	cout<<"Enter n :";
	cin>>n;
	long double a[n],t[n];
	long double x;
	for(i=0;i<n;i++)
	{
		cin>>a[i];
		t[i]=a[i];
	}
	x=tonytime(a,t,n);
	cout<<x;
}
