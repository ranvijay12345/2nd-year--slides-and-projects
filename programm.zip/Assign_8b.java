import java.io.*;
import java.util.Scanner;

class students implements Serializable {
	public String fName;
	public String lName;
	public int roll;
	public float cpi;
	public int age;
	
	students (String fName, String lName, int roll, float cpi, int age ) {
		this.fName = fName; 
		this.lName = lName;
		this.roll = roll;
		this.cpi = cpi;
		this.age = age;
	}
	
	public String getDetails() {
		return ""+fName+""+lName+""+roll+""+cpi+""+age;
	}
}
public class Assing_8b {
	
	private static Object age;
	private static Scanner fileOut;

	public static void main(String [] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Input number of students:");
		int n = Integer.parseInt(sc.nextLine().trim());
		System.out.println("Input first name, last name, Roll no, cpi, age : ");
		Student stu = new Student();
		Student max = new Student();
		
		for(int i=0;i<10;i++) {
			stu.fName = sc.next();
			stu.lName = sc.next();
			stu.roll = sc.nextInt();
			stu.cpi = sc.nextFloat();
			stu.age = sc.nextInt();
			if(max.cpi > stu.cpi) {
				max.fName = stu.fName;
				max.lName = stu.lName;
				max.roll = stu.roll;
				max.cpi  = stu.cpi;
				max.age = stu.age;
				
				students (fName, lName, roll, cpi, age );
				
			}
		}

	
	students s1;
	try {
		FileOutputStream fileout = new FileOutputStream ("students.ser");
		
		ObjectOutputStream out = new ObjectOutputStream (fileout);
		
		out.writeObject(stu);
		out.close();
		
		fileOut.close();
	}
	catch (IOException i) {
		i.printStackTrace();
	}
	System.out.println();
	
	try {
		FileInputStream fin = new FileInputStream("Student.ser");
		@SuppressWarnings("resource")
		ObjectInputStream oin = new ObjectInputStream(fin);
		
		while(true) {
			s1 = (students) oin.readObject();System.out.println(stu.getDetails());
			
		}
	}
	catch (EOFException eof) {
		System.out.println("...end of file...");
	}
	catch (IOException ioe) {
		
	}
	catch (ClassNotFoundException cnf) {
		
	}
}

	private static void students(Object fName, Object lName, Object roll, Object cpi, Object age2) {
		// TODO Auto-generated method stub
		
	}
	}
