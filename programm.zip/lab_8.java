import java.util.Scanner;
class User extends RuntimeException
{  Scanner input1 = new Scanner(System.in);
	String firstName;
	String lastName,PAN,email;
	String PIN;
User(){}
User(String pan)
{
	super(pan);
	System.out.println("Exception in PAN format");
}
User(String pin,int x)
{
  super(pin);
System.out.println("Exception in PIN format");
}  
User(String f,String l,String p,String e,String pin)
{
firstName = f;
lastName = l;
PAN = p;
email = e;
PIN = pin;
}
void setDetails()
{
  System.out.println("Enter First Name : ");
  firstName = input1.nextLine();
  System.out.println("Enter Last Name : ");
  lastName = input1.nextLine();
  System.out.println("Enter PAN : ");
  PAN = input1.nextLine();
  System.out.println("Enter Email Id : ");
  email = input1.nextLine();
  System.out.println("Enter PIN : ");
  PIN = input1.nextLine();
}
void printDetails()
{
  System.out.println("First Name : "+firstName);
  System.out.println("Last Name : "+lastName);
  System.out.println("PAN : "+PAN);
  System.out.println("email : "+email);
  System.out.println("PIN : "+PIN);
}

}
class Student extends User
{   Scanner input2 = new Scanner(System.in);
	int r;
	Student(){}
	Student(String f,String l,String p,String e,String pin,int roll)
	{
      super(f,l,p,e,pin);
      r = roll;
	}
	void setDetails()
	{
		super.setDetails();
		System.out.println("Enter roll number : ");
		r = input2.nextInt();
	}
   void printDetails()
   {
       super.printDetails();
       System.out.println("Roll no. is : "+r);
   }
}

class Employee extends User
{   Scanner input3 = new Scanner(System.in);
	int empID;
	Employee(){}
	Employee(String f,String l,String p,String e,String pin,int emp)
	{
		super(f,l,p,e,pin);
		empID = emp;
	}
	void setDetails()
	{
		super.setDetails();
        System.out.println("Enter employee ID");
        empID = input3.nextInt();	
	}

   void printDetails()
   {
      super.printDetails();
      System.out.println("Employee ID is : "+empID);
   }	
}   

 class lab_8
 {
    void Validate1(String pan)
	{
		if(pan.charAt(0) <65 || pan.charAt(0) >97)
			throw new User("PAN EXCEPTION");
		else
			System.out.println("NO Pan Exception");
	}
	void Validate2(String pin,int x)
	{

		if(pin.length()!=6)
			throw new User("PIN Exception");
		else
			System.out.println("No PIN exception");
	}		
		
   public static void main(String[] args)
   {
	   
	   lab8 l1 = new lab8();
	 //  l1.setDetails();  
      Student obj1 = new Student();
      obj1.setDetails();
	  System.out.println(" "+obj1.PAN.charAt(0));
	  Student obj2 = new Student();
	  obj2.setDetails();
	  obj1.printDetails();
      obj2.printDetails();
	  
	/*  Employee obj3 = new Employee();
	  obj3.setDetails();
	  obj3.printDetails();
	  if(obj3.PAN.charAt(0)<65 || obj3.PAN.charAt(0)>97)
		   throw new User("PAN EXCEPTION");
	  if(obj3.PIN.length()!=6)
	      throw new User("PIN EXCEPTION");
	  */
	  	  if(obj1.PAN.charAt(0)<65 || obj1.PAN.charAt(0)>97)
		  throw new User("PAN EXCEPTION");
	  	  if(obj2.PAN.charAt(0)<65 || obj2.PAN.charAt(0)>97)
		  throw new User("PAN EXCEPTION");
	 
	
   }
   
 }	
	
