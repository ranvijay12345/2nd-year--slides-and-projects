#include<stdio.h>
int divideMax(int[],int,int);
int divideMin(int[],int,int);
int findmax(int,int);
int findmin(int,int);


int main()
{
    int a[8] = {7,9,1,3,5,11,27,4};
    int lb=0,ub=7,max,min;
    max =  divideMax(a,lb,ub);
    min = divideMin(a,lb,ub);
   printf("\nMaximum element is : %d\n",max);
    printf("\nMinimum element is : %d",min);

  // printf("Maximum : %d\n",Maximum);
  // printf("Minimum : %d",Minimum);
   return 0;

}
int divideMax(int a[],int lb,int ub)
{ if(lb<ub)
   {
    int mid = (lb+ub)/2;
    int max1,max2,max;
    max1 = divideMax(a,lb,mid);
    max2 = divideMax(a,mid+1,ub);
     max =  findmax(max1,max2);
    return max;
   }
   if(lb == ub)
    return a[lb];
}
int divideMin(int a[],int lb,int ub)
{ if(lb<ub)
   {
    int mid = (lb+ub)/2;
    int max1,max2,min;
    max1 = divideMin(a,lb,mid);
    max2 = divideMin(a,mid+1,ub);
     min =  findmin(max1,max2);
   //  printf("MInimum is : %d",min);
    return min;
   }
   if(lb == ub)
    return a[lb];
}

int findmax(int x,int y)
{
 if(x>y)
    return x;
 else
 return y;

}
int findmin(int x,int y)
{
 if(x<y)
    return x;
 else
 return y;

}


