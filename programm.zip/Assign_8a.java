import java.io.*;
 
public class Assign_8a
{   
    public static void main(String[] args) throws IOException
    {   

        File f1 = new File(args[0]);
        File f2 = new File(args[1]);

        FileReader fR1 = new FileReader(f1);
        BufferedReader reader1 = new BufferedReader(fR1);
        String line1 = reader1.readLine();
         
         
        boolean areEqual = true;
         
        int lineNum1 = 1;
          System.out.println("Following words are common in both the files with the following details: ");
           while (line1 != null)
           {
               FileReader fR2 = new FileReader(f2);

               BufferedReader reader2 = new BufferedReader(fR2);
              String line2 = reader2.readLine();
              int lineNum2 = 1;
               
             while (line2 != null)
             {
                   
                  if(line1.equalsIgnoreCase(line2))
                   {
                      System.out.println(line1+ "  length " +line1.length()+ "  , appeared in  " +lineNum1+ " line of " +args[0]+ " and " +lineNum2+  "  in" +args[1] );
                      }
                 line2 = reader2.readLine();
                 lineNum2++;
              }  
               reader2.close(); 
               line1 = reader1.readLine();
               lineNum1++;
         }
         
        reader1.close();
         
        reader2.close();
    }
}