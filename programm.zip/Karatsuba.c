#include <stdio.h>
#include <stdlib.h>

int countDigits(int num)
{
    if (num < 10)
        return 1;
    else
        return 1 + countDigits(num / 10);
}

int max(int num1, int num2)
{
    return (num1 > num2) ? num1 : num2;
}

int power(int num, int i)
{
    if(i == 0)
        return 1;
    else
        return num * power(num, i- 1);
}

int* split(int num, int m)
{
    int* arr = (int*)calloc(2, sizeof(int));
    arr[0] = num / power(10, m);
    arr[1] = num % power(10, m);
    return arr;
}

int karatsuba(int num1, int num2)
{
    if ((num1 < 10) || (num2 < 10))
        return num1 * num2;
    int n = max(countDigits(num1), countDigits(num2));
    int m = n / 2;
    int *X = split(num1, m);
    int *Y = split(num2, m);
    int a = karatsuba(X[0], Y[0]);
    int d = karatsuba(X[1], Y[1]);
    int e = karatsuba((X[0] + X[1]), (Y[1] + Y[0])) - a - d;

    return (a * power(10, n)) + (e * power(10, m)) + d;
}

void main()
{
    int num1, num2;

    printf("Enter the first number: ");
    scanf("%d", &num1);

    printf("Enter the second number: ");
    scanf("%d", &num2);

    printf("The product is : %d\n", karatsuba(num1, num2));
}
