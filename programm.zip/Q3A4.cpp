#include <iostream>
using namespace std;
int *multiply(int A[], int B[], int m, int n)
{
   int *result = new int[m+n-1];

   for (int i = 0; i<(m+n-1); i++)
     result[i] = 0;


   for (int i=0; i<m; i++)
   { for (int j=0; j<n; j++)
         result[i+j] =result[i+j] +  A[i]*B[j];
   }

   return result;
}
int main()
{  int i;
    int A[] = {5, 0, 10, 6};
    int B[] = {1, 2, 4};
    int m = sizeof(A)/sizeof(A[0]);
    int n = sizeof(B)/sizeof(B[0]);


    int *result = multiply(A, B, m, n);

    cout << "\nProduct of two polynomial is :  ";
    for(i=0;i<(m+n-1);i++)
      cout<<result[i]<<" ";
    return 0;
}
