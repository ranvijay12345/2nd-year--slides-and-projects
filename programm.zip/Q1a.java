import java.util.Scanner;

public class main
{
    public static void main(String[] args)
    {
        String name;
        double rollnumber;
        char gender;
        int age;
        
        Scanner console=new Scanner(System.in);
        
        System.out.print("Enter Student name : ");
        name=console.nextLine();
        
        System.out.print("Enter Roll number : ");
        rollnumber=console.nextDouble();
        
        System.out.print("Enter Gender : ");
        gender=console.next().charAt(0);
        
        System.out.print("Enter Age : ");
        age=console.nextInt();
        
        System.out.println("Student name is " + name +". Roll number of student is "+ rollnumber +" Gender is "+ gender +". Age is "+ age+"." );
        
        
    }
}