#include<stdio.h>
#include<conio.h>

long double max(long double a,long double b)
{
	if(a>b)
	return a;
	else
	return b;
}
long double* shift(long double len[],int ind,int n)
{
	int i;
	for(i=ind;i<n-1;i++)
	{
		len[i]=len[i+1];
	}
	len[n-1]=0;
	return len;
}
long double tonytime(long double len[],long double time[],int n)
{
   
    int i,j,k;
    long double sum=0;
	if(n==0)
	return 0;
	else
	{
		sum=0;
   for(j=0;j<n;j++)
   {
    
		for(i=j;i<n;i++)
		{
			if(i>0&&i<n-1)
			sum=max(sum,len[i]+len[i-1]/2+len[i+1]/2+tonytime(shift(len,i,n),time,n-1));
			else
			{
				if(i==0)
				sum=max(sum,len[i]+len[i+1]/2+tonytime(shift(len,i,n),time,n-1));
				if(i==n-1)
				sum=max(sum,len[i]+len[i-1]/2+tonytime(shift(len,i,n),time,n-1));
			}
	   }
  }
}
	return sum;
}
int main()
{
	int n,i;
	printf("Enter value of n : ");
	scanf("%d",&n);
	long double a[n],t[n];
	long double x;
	for(i=0;i<n;i++)
	{
		scanf("%Lf",a[i]);
		t[i]=a[i];
	}
	x=tonytime(a,t,n);
	printf("%Lf",x);
	
	FILE *file;
	file = fopen("Spaceships.txt","a");
    fprintf(file, "Output : ");
    for(int i = 0; i<n; i++)
    {
        fprintf(file, "%Lf",x);
    }
    fclose(file);
    getch();
    return 0;
}

