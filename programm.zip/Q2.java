import java.util.Scanner;
import java.util.Arrays; 
import java.util.Collections; 

public class Main
{
    public static void kLargest(Integer[] a, int k) 
    { 
        Arrays.sort(a, Collections.reverseOrder()); 
  
        // Print the first kth largest elements 
        for (int i = 0; i < k; i++) 
            System.out.print(a[i] + " "); 
    } 
    
    public static void main(String[] args) 
    {
        int n,j,k;
        Scanner s = new Scanner(System.in);
        System.out.print("Enter no. of elements you want in array:");
        n = s.nextInt();
        int a[] = new int[n];
        System.out.println("Enter all the elements:");
        for(int i = 0; i < n; i++)
        {
            a[i] = s.nextInt();
        }
        System.out.println("Entered numbers are : ");
        for(j=0;j<n;j++)
        {
            System.out.print(a[j]+" ");
        }
        System.out.print("Enter value of k : "):
        k=s.nextInt();
        kLargest(a, k);
        
    }
}