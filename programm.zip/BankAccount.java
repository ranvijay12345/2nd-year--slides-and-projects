import java.util.Scanner;

class account 
{
 	private int accountNo;
 	private String accType;
 	private int avBalance;
 	private int costomerID;
 	private String name;
 

  	Scanner s = new Scanner(System.in);

  	void openAccount()
  	{
   		System.out.print("Enter account No : ");
   		accountNo=s.nextint();
   
   		System.out.print("Enter account Type : ");
   		accType=s.next();

   		System.out.print("Enter Balance : ");
   		avBalance=s.nextint();

   		System.out.print("Enter your CostomerID : ");
   		costomerID=s.nextint();

   		System.out.print("Enter Name : ");
   		name=s.next();

   	   }

   	void showAccount()
   	{
     		System.out.println(accountNo + "," + accType + "," + avBalance + costomerID + "," + name);
   	 }

	void deposit();
	{
		int amt;
		System.out.println("Enter amount tou want to deposit : ");
		amt = s.nextint();
		avBalance = avBalance + amt;
	}

    	void withdrawal()
    	{
      		int amt;
      		System.out.println("Entre amount you want to Withdrawal : ");
      		amt = s.nextint();
      		if(avBalance >= amt)
      		{
        			avBalance = avBalance - amt;
       		}
       		else
        		{
         		System.out.println("Less Balence....Transiction Failed..");
         		}
        	}
      
      	boolean search(String acn)
      	{
        		if(accountNo.equals(acn))
         	{
           	showAccount();
           	return true;
           	}
           	return false;
       }
}

public class Main {
	public static void main (String[] args){
		scanner s = new Scanner(System.in);
		
		System.out.print("Enter the nmber of customer : ");
		int n = s.nextint();
		account C[] = new account[n];
		for(int i = 0 ; i < C.length; i++)
		{
			C[i] = new account();
			C[i].openAccount();
		}

		int ch;
		while (ch !=5)
  		{
			System.out.println("Main Menu\n1. Display All\n 2. Search By Account\n 3. Deposit\n 4. Withdrawal\n 5.E xit ");
			System.out.println("Your choice : ");
			ch = s.nextint();
			switch(ch)
			{
				case 1: 
					for(int i=0;i<C.length; i++){
					C[i]=showAccount(); }
					break;

				case 2:
    					System.out.print("Enter account you want to search..");
					acn=s.next();
					boolean found = false;
					for(int i=0;i<C.length;i++){
						found = C[i].search(acn);
						if (found){
						    break;
						}
					}
					if (!found) {
                           				System.out.println("Search Failed..Account Not Exist..");
                       				}
                        				break;
				
				case 3:
                        				System.out.print("Enter Account No : ");
                        				acn = KB.next();
                        				found = false;
                        				for (int i = 0; i < C.length; i++) {
                            					found = C[i].search(acn);
                           					if (found) {
                                				C[i].deposit();
                                				break;
                            					}
                        				}
                        				if (!found) {
                            				System.out.println("Search Failed..Account Not Exist..");
                        				}
                        				break;

                    			case 4:
                        				System.out.print("Enter Account No : ");
                        				acn = KB.next();
                        				found = false;
                        				for (int i = 0; i < C.length; i++) {
                            					found = C[i].search(acn);
                            					if (found) {
                                				C[i].withdrawal();
                                				break;
                           					}
                        				 }
                        					if (!found) {
                            					System.out.println("Search Failed..Account Not Exist..");
                        					}
                        					break;

                    			case 5:
                        				System.out.println("Good Bye..");
                        				break;
			}
		}
	}
}	
